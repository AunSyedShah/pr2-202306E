from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home():
    username = "Sir Aun"
    friends = ["daniyal", "amir", "youhanna"]

    fruits = [
        {
            "fruit_name": "Mango",
            "price": 350,
            "img": "https://images.unsplash.com/photo-1550258987-190a2d41a8ba"
        },
        {
            "fruit_name": "Banana",
            "price": 250,
            "img": "https://images.unsplash.com/photo-1574226516831-e1dff420e12a"
        },
        {
            "fruit_name": "Orange",
            "price": 420,
            "img": "https://images.unsplash.com/photo-1587314168485-3236f79a1a59"
        },
        {
            "fruit_name": "Apple",
            "price": 300,
            "img": "https://images.unsplash.com/photo-1567306226416-28f0efdc88ce"
        },
        {
            "fruit_name": "Strawberry",
            "price": 600,
            "img": "https://images.unsplash.com/photo-1502741338009-cac2772e18bc"
        },
        {
            "fruit_name": "Pineapple",
            "price": 500,
            "img": "https://images.unsplash.com/photo-1502747946081-ec86c4485f13"
        },
        {
            "fruit_name": "Grapes",
            "price": 450,
            "img": "https://images.unsplash.com/photo-1576402187878-974f70eca1f8"
        },
        {
            "fruit_name": "Watermelon",
            "price": 300,
            "img": "https://images.unsplash.com/photo-1598514982841-7f5b1b509c9c"
        },
        {
            "fruit_name": "Kiwi",
            "price": 700,
            "img": "https://images.unsplash.com/photo-1547514701-42782101795d"
        },
        {
            "fruit_name": "Pomegranate",
            "price": 550,
            "img": "https://images.unsplash.com/photo-1601004890684-d8cbf643f5f2"
        },
    ]

    context = {
        "username": username,
        "friends": friends,
        "fruits": fruits
    }

    return render_template("index.html", **context)
